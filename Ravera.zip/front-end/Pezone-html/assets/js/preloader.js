$(document).ready(function() {
	
	setTimeout(function(){
		$('body').addClass('loaded'); 
	}, 2500);
	
});